const $ = id => document.getElementById(id);
let chart;
const fmt = n => new Intl.NumberFormat("kk-KZ").format(Number(n || 0));
function notice(msg){$("notice").textContent=msg;$("notice").classList.remove("hidden")}
async function api(url, options={}) {
  const r=await fetch(url,{...options,headers:options.headers||{}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(d.error||"Сұраныс орындалмады");
  return d;
}
async function loadDashboard(){
  try{
    const d=await api("/api/dashboard"),c=d.channel;
    $("channelName").textContent=c.title;$("channelId").textContent="Channel ID: "+c.id;
    $("avatar").src=c.thumbnail||"";$("subs").textContent=c.hiddenSubscribers?"Жасырылған":fmt(c.subscribers);
    $("views").textContent=fmt(c.views);$("count").textContent=fmt(c.videoCount);
    $("videos").innerHTML="";
    if(!d.videos.length)$("videos").textContent="Видео табылмады.";
    d.videos.forEach(v=>{
      const card=document.createElement("article");card.className="video";
      const img=document.createElement("img");img.src=v.thumbnail;img.alt="";
      const box=document.createElement("div"),title=document.createElement("b"),meta=document.createElement("p");
      title.textContent=v.title;meta.className="hint";meta.textContent="Көрілім: "+fmt(v.views);
      box.append(title,meta);card.append(img,box);$("videos").append(card);
    });
  }catch(e){notice(e.message)}
}
function defaultDates(){
  const end=new Date(),start=new Date();start.setDate(start.getDate()-28);
  $("endDate").value=end.toISOString().slice(0,10);$("startDate").value=start.toISOString().slice(0,10);
}
async function init(){
  const me=await api("/api/me");
  if(me.connected){$("welcome").classList.add("hidden");$("app").classList.remove("hidden");$("logout").classList.remove("hidden");await loadDashboard();defaultDates()}
  const p=new URLSearchParams(location.search);
  if(p.has("error"))notice("Google кіру қатесі. OAuth баптауын тексеріңіз.");
  history.replaceState({},"","/");
}
$("refresh").addEventListener("click",loadDashboard);
$("logout").addEventListener("click",async()=>{await api("/auth/logout",{method:"POST"});location.reload()});
$("generate").addEventListener("click",async()=>{
  const btn=$("generate");btn.disabled=true;btn.textContent="Дайындалып жатыр…";
  try{
    const d=await api("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      topic:$("topic").value,format:$("format").value,language:$("genLanguage").value
    })});
    $("title").value=d.title;$("description").value=d.description;$("script").value=d.script;
    $("tags").value=(d.tags||[]).join(", ");$("draft").classList.remove("hidden");
    $("publish").disabled=false;
  }catch(e){notice(e.message)}
  finally{btn.disabled=false;btn.textContent="✦ AI арқылы идея және сценарий жасау"}
});
$("videoFile").addEventListener("change",()=>{$("publish").disabled=!$("videoFile").files.length});
$("publish").addEventListener("click",async()=>{
  if(!confirm("Мақұлдайсыз ба? Видео арнаңызға PRIVATE күйінде жүктеледі. Көпшілікке автоматты жарияланбайды."))return;
  const file=$("videoFile").files[0];if(!file)return;
  const btn=$("publish");btn.disabled=true;$("uploadStatus").textContent="Видео жүктелуде…";
  const form=new FormData();form.append("video",file);form.append("approval","APPROVE_UPLOAD_PRIVATE");
  form.append("title",$("title").value);form.append("description",$("description").value);form.append("tags",$("tags").value);
  try{
    const r=await fetch("/api/publish",{method:"POST",body:form});
    const d=await r.json();if(!r.ok)throw new Error(d.error||"Жүктеу қатесі");
    $("uploadStatus").textContent=d.message+" ";
    const a=document.createElement("a");a.href=d.url;a.target="_blank";a.rel="noopener";a.textContent="YouTube Studio-да ашу";$("uploadStatus").append(a);
    await loadDashboard();
  }catch(e){$("uploadStatus").textContent=e.message}
  finally{btn.disabled=!$("videoFile").files.length}
});
$("loadAnalytics").addEventListener("click",async()=>{
  $("analyticsMessage").textContent="Жүктелуде…";
  try{
    const q=new URLSearchParams({startDate:$("startDate").value,endDate:$("endDate").value});
    const d=await api("/api/analytics?"+q);
    const ix=d.columns.indexOf("day"),iv=d.columns.indexOf("views"),is=d.columns.indexOf("subscribersGained");
    if(!d.rows.length){$("analyticsMessage").textContent="Бұл аралықта дерек жоқ.";return}
    if(chart)chart.destroy();
    chart=new Chart($("chart"),{type:"line",data:{labels:d.rows.map(r=>r[ix]),datasets:[
      {label:"Көрілім",data:d.rows.map(r=>r[iv]),borderColor:"#ff3944",tension:.3},
      {label:"Жаңа жазылушылар",data:d.rows.map(r=>r[is]),borderColor:"#8e8aff",tension:.3}
    ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{color:"#ddd"}}},
      scales:{x:{ticks:{color:"#aaa"}},y:{ticks:{color:"#aaa"}}}}});
    $("analyticsMessage").textContent="Аналитика жаңартылды.";
  }catch(e){$("analyticsMessage").textContent=e.message}
});
init().catch(e=>notice(e.message));
