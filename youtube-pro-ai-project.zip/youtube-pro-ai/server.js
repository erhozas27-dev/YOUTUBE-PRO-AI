require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const SQLiteStore = SQLiteStoreFactory(session);
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const { google } = require("googleapis");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === "production";
const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

const required = ["SESSION_SECRET", "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_REDIRECT_URI"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing environment variables:", missing.join(", "));
  process.exit(1);
}
if (production) app.set("trust proxy", 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://cdn.jsdelivr.net"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "https:", "data:"],
      connectSrc: ["'self'"]
    }
  }
}));
app.use(express.json({ limit: "200kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir, table: "sessions" }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: production,
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));
app.use(express.static(path.join(__dirname, "public")));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 25 });
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 100 });
app.use("/auth", authLimiter);
app.use("/api", apiLimiter);

const SCOPES = [
  "openid", "email", "profile",
  "https://www.googleapis.com/auth/youtube.readonly",
  "https://www.googleapis.com/auth/youtube.upload",
  "https://www.googleapis.com/auth/yt-analytics.readonly"
];

function oauthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}
function requireAuth(req, res, next) {
  if (!req.session.tokens) return res.status(401).json({ error: "Алдымен Google аккаунтыңызды қосыңыз." });
  next();
}
function getYouTube(req) {
  const auth = oauthClient();
  auth.setCredentials(req.session.tokens);
  auth.on("tokens", tokens => {
    req.session.tokens = { ...req.session.tokens, ...tokens };
  });
  return google.youtube({ version: "v3", auth });
}
function requireApproval(req, res, next) {
  if (req.body.approval !== "APPROVE_AND_PUBLISH") {
    return res.status(400).json({ error: "Жариялау үшін мақұлдау батырмасын басыңыз." });
  }
  next();
}

app.get("/auth/google", (req, res) => {
  const state = crypto.randomBytes(24).toString("hex");
  req.session.oauthState = state;
  res.redirect(oauthClient().generateAuthUrl({
    access_type: "offline",
    prompt: "consent",
    include_granted_scopes: true,
    scope: SCOPES,
    state
  }));
});

app.get("/auth/google/callback", async (req, res) => {
  try {
    if (!req.query.state || req.query.state !== req.session.oauthState) {
      return res.status(400).send("OAuth қауіпсіздік тексеруі өтпеді. Қайта кіріңіз.");
    }
    delete req.session.oauthState;
    if (req.query.error) return res.redirect("/?auth=cancelled");
    const auth = oauthClient();
    const { tokens } = await auth.getToken(String(req.query.code || ""));
    if (!tokens.access_token) throw new Error("No access token");
    req.session.tokens = tokens;
    auth.setCredentials(tokens);
    const user = await google.oauth2({ version: "v2", auth }).userinfo.get();
    req.session.user = {
      name: user.data.name || "YouTube авторы",
      email: user.data.email || "",
      picture: user.data.picture || ""
    };
    req.session.save(() => res.redirect("/"));
  } catch (e) {
    console.error("OAuth error:", e.message);
    res.redirect("/?error=oauth");
  }
});

app.post("/auth/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/me", (req, res) => res.json({ connected: !!req.session.tokens, user: req.session.user || null }));

app.get("/api/dashboard", requireAuth, async (req, res) => {
  try {
    const yt = getYouTube(req);
    const result = await yt.channels.list({ part: ["snippet", "statistics", "contentDetails"], mine: true });
    const ch = result.data.items?.[0];
    if (!ch) return res.status(404).json({ error: "Бұл Google аккаунтта YouTube арнасы табылмады." });
    const uploads = ch.contentDetails?.relatedPlaylists?.uploads;
    let videos = [];
    if (uploads) {
      const pl = await yt.playlistItems.list({ part: ["snippet", "contentDetails"], playlistId: uploads, maxResults: 8 });
      const ids = (pl.data.items || []).map(x => x.contentDetails?.videoId).filter(Boolean);
      if (ids.length) {
        const vr = await yt.videos.list({ part: ["snippet", "statistics"], id: ids.join(",") });
        videos = (vr.data.items || []).map(v => ({
          id: v.id, title: v.snippet?.title || "",
          thumbnail: v.snippet?.thumbnails?.medium?.url || "",
          views: Number(v.statistics?.viewCount || 0),
          publishedAt: v.snippet?.publishedAt || ""
        }));
      }
    }
    res.json({
      channel: {
        id: ch.id, title: ch.snippet?.title || "",
        thumbnail: ch.snippet?.thumbnails?.medium?.url || "",
        subscribers: Number(ch.statistics?.subscriberCount || 0),
        views: Number(ch.statistics?.viewCount || 0),
        videoCount: Number(ch.statistics?.videoCount || 0),
        hiddenSubscribers: !!ch.statistics?.hiddenSubscriberCount
      }, videos
    });
  } catch (e) {
    console.error("Dashboard:", e.message);
    res.status(500).json({ error: "YouTube деректерін алу мүмкін болмады. API және OAuth рұқсатын тексеріңіз." });
  }
});

app.get("/api/analytics", requireAuth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const dateRe = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRe.test(startDate || "") || !dateRe.test(endDate || "") || startDate > endDate) {
      return res.status(400).json({ error: "Күн форматы YYYY-MM-DD болуы керек." });
    }
    const auth = oauthClient();
    auth.setCredentials(req.session.tokens);
    const analytics = google.youtubeAnalytics({ version: "v2", auth });
    const r = await analytics.reports.query({
      ids: "channel==MINE", startDate, endDate,
      metrics: "views,likes,comments,subscribersGained,subscribersLost",
      dimensions: "day", sort: "day"
    });
    res.json({ columns: (r.data.columnHeaders || []).map(x => x.name), rows: r.data.rows || [] });
  } catch (e) {
    console.error("Analytics:", e.message);
    res.status(500).json({ error: "Analytics деректерін алу мүмкін болмады." });
  }
});

async function generateWithAI(topic, language, format) {
  const kk = language !== "ru";
  const system = kk
    ? "Сен YouTube контент редакторысan. Қазақ тілінде нақты, қызықты, шынайы контент дайында. Ойдан шығарылған факт жазба. JSON ғана қайтар: title, description, script, tags массиві."
    : "Ты редактор YouTube. Пиши по-русски, интересно и достоверно, не выдумывай факты. Верни только JSON: title, description, script, tags array.";
  const prompt = `Канал тақырыбы: ${topic}. Формат: ${format}. YouTube-қа арналған видео идеясын, қысқа сценарийін, сипаттамасын және 5-8 хэштег дайында.`;

  if (process.env.AI_API_KEY) {
    const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
    const response = await fetch(base + "/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        temperature: 0.7,
        response_format: { type: "json_object" },
        messages: [{ role: "system", content: system }, { role: "user", content: prompt }]
      })
    });
    if (!response.ok) throw new Error("AI provider returned " + response.status);
    const data = await response.json();
    const parsed = JSON.parse(data.choices?.[0]?.message?.content || "{}");
    return {
      title: String(parsed.title || "").slice(0, 100),
      description: String(parsed.description || "").slice(0, 5000),
      script: String(parsed.script || "").slice(0, 12000),
      tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 12).map(String) : []
    };
  }

  const title = kk ? `${topic}: қызықты деректер мен жаңа көзқарас` : `${topic}: интересные факты и новый взгляд`;
  const description = kk
    ? `Бұл видеода «${topic}» тақырыбын қарастырамыз. Ақпаратты тексеріп, өз пікіріңізді комментарийге қалдырыңыз.`
    : `В этом видео разбираем тему «${topic}». Проверяйте источники и делитесь мнением в комментариях.`;
  const script = kk
    ? `КІРІСПЕ\nСәлем! Бүгін біз «${topic}» туралы сөйлесеміз.\n\nНЕГІЗГІ БӨЛІМ\n1. Тақырыпқа қысқаша шолу жасаңыз.\n2. Сенімді дереккөздерден тексерілген 3 негізгі факт қосыңыз.\n3. Көрерменге пайдалы қорытынды айтыңыз.\n\nҚОРЫТЫНДЫ\nКөргеніңізге рақмет! Пікіріңізді жазыңыз.`
    : `ВСТУПЛЕНИЕ\nПривет! Сегодня говорим о теме «${topic}».\n\nОСНОВНАЯ ЧАСТЬ\n1. Кратко объясните тему.\n2. Добавьте три проверенных факта из надёжных источников.\n3. Сформулируйте полезный вывод.\n\nЗАВЕРШЕНИЕ\nСпасибо за просмотр! Напишите своё мнение.`;
  return { title, description, script, tags: kk ? ["#YouTube", "#Қызықты", "#Shorts"] : ["#YouTube", "#Интересное", "#Shorts"] };
}

app.post("/api/generate", requireAuth, async (req, res) => {
  try {
    const topic = String(req.body.topic || "").trim().slice(0, 180);
    const language = req.body.language === "ru" ? "ru" : "kk";
    const format = ["Shorts", "Ұзын видео", "Long video"].includes(req.body.format) ? req.body.format : "Shorts";
    if (!topic) return res.status(400).json({ error: "Канал тақырыбын енгізіңіз." });
    res.json(await generateWithAI(topic, language, format));
  } catch (e) {
    console.error("AI generation:", e.message);
    res.status(502).json({ error: "AI мәтінін жасау мүмкін болмады. AI API баптауын тексеріңіз." });
  }
});

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
  storage,
  limits: { fileSize: 1.8 * 1024 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith("video/")) return cb(new Error("Тек видео файл жүктеуге болады."));
    cb(null, true);
  }
});

// The upload endpoint requires an explicit approval value from the UI.
// The video is sent as PRIVATE first. User can review it in YouTube Studio and publish there.
app.post("/api/publish", requireAuth, upload.single("video"), async (req, res) => {
  const filePath = req.file?.path;
  try {
    if (req.body.approval !== "APPROVE_UPLOAD_PRIVATE") {
      return res.status(400).json({ error: "Алдымен видео жүктеуге келісім беріңіз." });
    }
    if (!req.file) return res.status(400).json({ error: "Жүктейтін видео файлын таңдаңыз." });
    const title = String(req.body.title || "").trim().slice(0, 100);
    const description = String(req.body.description || "").trim().slice(0, 5000);
    if (!title) return res.status(400).json({ error: "Видео атауы қажет." });

    const yt = getYouTube(req);
    const result = await yt.videos.insert({
      part: ["snippet", "status"],
      requestBody: {
        snippet: {
          title, description,
          tags: String(req.body.tags || "").split(",").map(x => x.trim().replace(/^#/, "")).filter(Boolean).slice(0, 30),
          categoryId: "22"
        },
        status: { privacyStatus: "private", selfDeclaredMadeForKids: false }
      },
      media: { body: fs.createReadStream(filePath) }
    });
    res.json({
      ok: true,
      videoId: result.data.id,
      url: `https://studio.youtube.com/video/${result.data.id}/edit`,
      message: "Видео PRIVATE күйінде арнаға жүктелді. Оны YouTube Studio ішінде тексеріп, өзіңіз жариялай аласыз."
    });
  } catch (e) {
    console.error("Upload error:", e.message);
    res.status(500).json({ error: "Видео жүктелмеді. Файл көлемін, OAuth upload рұқсатын және Google API квотасын тексеріңіз." });
  } finally {
    if (filePath) fs.promises.unlink(filePath).catch(() => {});
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`YOUTUBE PRO AI: http://localhost:${PORT}`));
