# YOUTUBE PRO AI — іске қосу нұсқаулығы

Бұл жоба:
- Google OAuth арқылы YouTube арнасына қосылады.
- Арна статистикасы мен соңғы видеоларды көрсетеді.
- Тақырыпқа қарай видео атауы, сипаттамасы, сценарийі және хэштегтерін дайындайды.
- Пайдаланушы мақұлдаған видеоны YouTube-қа **PRIVATE** күйінде жүктейді.
- Видео көпшілікке автоматты түрде жарияланбайды. Оны YouTube Studio ішінде тексеріп, жариялауды өзіңіз аяқтайсыз.

## 1. Қажетті құралдар
Node.js 20+, Google аккаунты, YouTube арнасы және Google Cloud жобасы.

## 2. Google API
1. https://console.cloud.google.com/ ашып, жоба жасаңыз.
2. YouTube Data API v3 және YouTube Analytics API қосыңыз.
3. Google Auth Platform бөлімінде OAuth consent screen баптаңыз. Testing режимінде өз аккаунтыңызды Test users ішіне қосыңыз.
4. Credentials → Create credentials → OAuth client ID → Web application таңдаңыз.
5. Authorized redirect URI:
   `http://localhost:3000/auth/google/callback`
6. Client ID және Client Secret мәндерін алыңыз.

Құжаттар:
- https://developers.google.com/youtube/v3
- https://developers.google.com/youtube/analytics
- https://developers.google.com/identity/protocols/oauth2/web-server
- https://developers.google.com/youtube/v3/guides/uploading_a_video

## 3. Орнату
```bash
npm install
```
`.env.example` файлын `.env` деп көшіріп, мәндерді толтырыңыз:
```env
PORT=3000
NODE_ENV=development
SESSION_SECRET=ұзын-кездейсоқ-құпия-жол
GOOGLE_CLIENT_ID=Google-дан-алынған-client-id
GOOGLE_CLIENT_SECRET=Google-дан-алынған-client-secret
GOOGLE_REDIRECT_URI=http://localhost:3000/auth/google/callback

# Қосымша: AI мәтін генерациясы үшін OpenAI үйлесімді API
AI_API_KEY=
AI_MODEL=gpt-4o-mini
AI_BASE_URL=https://api.openai.com/v1
```
AI_API_KEY бос болса, сайт кіріктірілген үлгі сценарийін береді. Нақты AI генерациясы үшін өзіңіздің API провайдеріңіздің кілтін сервердегі `.env` ішіне енгізіңіз. API кілтін браузерге немесе GitHub-қа салмаңыз.

Серверді іске қосу:
```bash
npm start
```
Сайт: http://localhost:3000

## 4. Интернетке жариялау
GitHub репозиторийіне кодты жүктеңіз (`.env` және `uploads/` қоспаңыз). Node.js қолдайтын хостингте:
- Build: `npm install`
- Start: `npm start`
- Environment variables: `.env` мәндерін хостингке енгізіңіз.
- `NODE_ENV=production`
- `GOOGLE_REDIRECT_URI` HTTPS доменіңіздегі `/auth/google/callback` болсын.
- Google Cloud OAuth клиентіндегі Authorized redirect URI-ді де дәл сол HTTPS URL-ге өзгертіңіз.
- `data/` бумасына тұрақты диск қажет, себебі сессиялар SQLite-те сақталады.

## Қауіпсіздік және шектеулер
- `.env` файлын ешқашан GitHub-қа жүктемеңіз.
- Тек HTTPS қолданыңыз.
- Google OAuth рұқсаттарын өз арнаңызға ғана беріңіз.
- Бұл бастапқы нұсқа жүктеуді PRIVATE күйінде жасайды; PUBLIC жариялау функциясы әдейі қосылмаған.
- Google API квотасы мен OAuth verification талаптары қолданылуы мүмкін.
- Өндірістік пайдалануға шығар алдында тұрақты сессия сақтау, CSRF қорғанысы, файл өлшемі/формат шектеулері, жүктеу прогресі, журналдау және деректерді сақтау саясатын күшейтіңіз.
- AI ұсынған мәтін мен фактілерді жариялар алдында тексеріңіз.
